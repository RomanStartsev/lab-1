﻿#include <iostream>
using namespace std;

int main()
{
    cout << "Complected Startsev Roman" << endl;
    // Zadanie 2.2
    cout << 1.71 << endl; // integer or byte
    cout << 1E-6 << endl; // integer or byte
    cout << 0.314159E1F << endl; // integer or byte
    cout << .005 << endl; // integer or byte
    cout << 0051E-04 << endl; // integer or byte
    cout << 5.E+2 << endl; // integer or byte
    cout << 0e0 << endl; // integer or byte
    cout << 05.5 << endl; // integer or byte
    cout << 0 << endl; // integer or byte
    cout << 0X1E6 << endl; // integer or byte
    cout << 1234.56789L << endl; // error
    cout << 1e-2f << endl; // integer or byte
    cout << -12.3E-6 << endl; // integer or byte
    cout << +10e6 << endl; // integer or byte
    cout << 123456L << endl; // integer or byte
}
